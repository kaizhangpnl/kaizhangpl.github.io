

from rinoh.font.type1 import AdobeFontMetrics


if __name__ == '__main__':
    afm = AdobeFontMetrics(r'..\rinoh\data\fonts\adobe14\Times-Roman.afm')
