.. _paper:

Paper sizes (:mod:`rinoh.paper`)
================================

.. automodule:: rinoh.paper
    :members:
