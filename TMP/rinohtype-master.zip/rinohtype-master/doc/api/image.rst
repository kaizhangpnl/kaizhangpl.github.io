.. _image:

Images and Figures (:mod:`rinoh.image`)
=======================================

.. automodule:: rinoh.image
    :members:
    :exclude-members: CaptionStyle, FigureStyle
