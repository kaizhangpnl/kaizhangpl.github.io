.. _dimension:

Dimension (:mod:`rinoh.dimension`)
==================================

.. automodule:: rinoh.dimension
    :members:
