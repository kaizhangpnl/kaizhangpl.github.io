.. _index:

Index (:mod:`rinoh.index`)
==========================

.. automodule:: rinoh.index
    :members:
    :exclude-members: IndexStyle
