.. _font:

Fonts and Typefaces (:mod:`rinoh.font`)
=======================================

.. automodule:: rinoh.font
    :members:
    :exclude-members: CaptionStyle, FigureStyle
