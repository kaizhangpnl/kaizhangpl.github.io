.. _reference:

Cross-References and Fields (:mod:`rinoh.reference`)
====================================================

.. automodule:: rinoh.reference
    :members:
    :exclude-members: ReferencingParagraphStyle, NoteMarkerStyle
