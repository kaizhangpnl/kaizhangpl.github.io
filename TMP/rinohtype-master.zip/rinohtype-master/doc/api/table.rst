.. _table:

Tables (:mod:`rinoh.table`)
===========================

.. automodule:: rinoh.table
    :members:
    :exclude-members: TableStyle, TableCellStyle, TableCellBorderStyle,
                      TableCellBackgroundStyle
