.. module:: rinoh.strings

.. _strings:

Strings (:mod:`rinoh.strings`)
==============================

.. autoclass:: String
    :members:


.. autoclass:: StringCollection
    :members:


.. autoclass:: Strings
    :members:


.. autoclass:: StringField
    :members:
