.. _draw:

Drawing Primitives (:mod:`rinoh.draw`)
======================================

.. automodule:: rinoh.draw
    :members:
    :exclude-members: LineStyle, ShapeStyle
