.. _standard_templates:

Standard Document Templates
===========================

Rinohtype includes a number of document templates. These are configurable and
therefore should cater for most documents.

.. toctree::

    article
    book
