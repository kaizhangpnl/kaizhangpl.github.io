.. _rinoh:

.. autoprogram:: rinoh.__main__:parser
   :prog: rinoh
