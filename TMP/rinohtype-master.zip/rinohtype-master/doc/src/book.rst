
:orphan:

.. _src_book:

Book template source code
=========================

.. literalinclude:: /../src/rinoh/templates/book.py

