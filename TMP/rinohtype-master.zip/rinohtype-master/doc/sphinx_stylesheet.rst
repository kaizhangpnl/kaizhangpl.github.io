
:orphan:

.. _Sphinx style sheet:

Sphinx style sheet
==================

.. literalinclude:: /../src/rinoh/data/stylesheets/sphinx.rts
    :language: ini









