
.. raw:: rinoh

   ListOfTablesSection


.. table:: first table

   =====  =========  =========
     A      Simple     Table
   =====  =========  =========

Section 1
=========

.. raw:: rinoh

   ListOfTables(local=True)


.. table:: second table

   =====  =========  =========
     A      Simple     Table
   =====  =========  =========

Subsection 1
------------

.. raw:: rinoh

   ListOfTables(local=True)


.. table:: third table

   =====  =========  =========
     A      Simple     Table
   =====  =========  =========

.. table:: fourth table

   =====  =========  =========
     A      Simple     Table
   =====  =========  =========

Subsection 2
------------

.. raw:: rinoh

   ListOfTables(local=True)


.. table:: fifth table

   =====  =========  =========
     A      Simple     Table
   =====  =========  =========

Section 2
=========

.. raw:: rinoh

   ListOfTables(local=True)


.. table:: sixth table

   =====  =========  =========
     A      Simple     Table
   =====  =========  =========
