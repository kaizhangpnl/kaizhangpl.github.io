
.. raw:: rinoh

   ListOfFiguresSection


.. figure:: ../images/title.png

   first figure

Section 1
=========

.. raw:: rinoh

   ListOfFigures(local=True)


.. figure:: ../images/title.png

   second figure

Subsection 1
------------

.. raw:: rinoh

   ListOfFigures(local=True)


.. figure:: ../images/biohazard.png

   third figure

.. figure:: ../images/biohazard.png

   fourth figure


Subsection 2
------------

.. raw:: rinoh

   ListOfFigures(local=True)


.. figure:: ../images/title.png

   fifth figure

Section 2
=========

.. raw:: rinoh

   ListOfFigures(local=True)


.. figure:: ../images/title.png

   sixth figure
