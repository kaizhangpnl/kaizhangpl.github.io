.. issue 99

.. role:: raw-role(raw)
   :format: html latex

A paragraph containing :raw-role:`raw text`.
