
.. centered:: A centered paragraph.
