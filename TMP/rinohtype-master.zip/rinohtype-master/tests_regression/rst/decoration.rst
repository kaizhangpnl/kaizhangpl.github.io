.. header::

    Header

.. footer::

    Footer


Header and footer nodes are ignored.
