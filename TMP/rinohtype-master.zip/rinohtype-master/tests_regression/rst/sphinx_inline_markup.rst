Inline Markup roles:

:abbr:          :abbr:`LIFO (last-in, first-out)` :abbr:`KISS`
:command:       :command:`rm`
:dfn:           :dfn:`definition`
:file:          :file:`README.txt` :file:`Makefile`
:guilabel:      :guilabel:`&Cancel`
:kbd:           :kbd:`Control-x`
:mailheader:    :mailheader:`Content-Type`
:makevar:       :makevar:`var`
:manpage:       :manpage:`ls(1)`
:menuselection: :menuselection:`Menu --> Item`
:mimetype:      :mimetype:`png`
:newsgroup:     :newsgroup:`comp.lang.python`
:program:       :program:`rinoh`
:regexp:        :regexp:`.*`
:samp:          :samp:`print 1+{variable}`
