.. issue #95

.. note::

    Here is my footnote [#qq]_.

    .. [#qq] Here it is!
